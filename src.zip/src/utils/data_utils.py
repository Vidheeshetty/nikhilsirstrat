import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import os
from typing import List

def csv_to_parquet(csv_path, parquet_path):
    """
    Convert a CSV file in the root-level data directory to Parquet format.
    """
    df = pd.read_csv(csv_path)
    table = pa.Table.from_pandas(df)
    pq.write_table(table, parquet_path)

def load_atm_call_options_from_csvs(csv_dir: str) -> pd.DataFrame:
    """
    Loads and processes 15-min snapshot CSVs for ATM CALL options with nearest expiry.
    Args:
        csv_dir (str): Directory containing raw CSV files.
    Returns:
        pd.DataFrame: Cleaned DataFrame with only ATM CALL options for nearest expiry.
    """
    # Gather all CSV files
    csv_files = [os.path.join(csv_dir, f) for f in os.listdir(csv_dir) if f.endswith('.csv')]
    if not csv_files:
        raise FileNotFoundError(f"No CSV files found in {csv_dir}")

    # Load all CSVs into a single DataFrame
    df = pd.concat([pd.read_csv(f) for f in csv_files], ignore_index=True)

    # Ensure correct dtypes
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df['expiry'] = pd.to_datetime(df['expiry'])
    df['strike'] = df['strike'].astype(float)
    df['bid'] = df['bid'].astype(float)
    df['ask'] = df['ask'].astype(float)
    df['last'] = df['last'].astype(float)
    df['volume'] = df['volume'].astype(float)
    df['open_interest'] = df['open_interest'].astype(float)

    # Filter for nearest expiry
    nearest_expiry = df['expiry'].min()
    df = df[df['expiry'] == nearest_expiry]

    # Only CALL options
    df = df[df['option_type'].str.upper() == 'CE']

    # For each timestamp, find ATM strike (strike closest to median spot)
    atm_rows = []
    for ts, group in df.groupby('timestamp'):
        # Find the strike closest to the median strike (proxy for ATM)
        median_strike = group['strike'].median()
        atm_idx = (group['strike'] - median_strike).abs().idxmin()
        atm_rows.append(group.loc[atm_idx])
    atm_df = pd.DataFrame(atm_rows)
    atm_df = atm_df.sort_values('timestamp').reset_index(drop=True)
    return atm_df

# Example usage (uncomment to test)
# df = load_atm_call_options_from_csvs('data/nse')
# print(df.head()) 