from nautilus_trader.trading.strategy import Strategy, StrategyConfig
from nautilus_trader.model import InstrumentId, Quantity
from nautilus_trader.model.enums import OrderSide, PositionSide
from nautilus_trader.model.events import PositionOpened
from nautilus_trader.core.message import Event
from nautilus_trader.model import QuoteTick
import pandas as pd
from datetime import time
from collections import deque

class MyNSEStrategyConfig(StrategyConfig):
    instrument_id: InstrumentId
    sl_pct: float = 0.02  # 2% stop-loss (legacy, not used in new logic)
    tp_pct: float = 0.03  # 3% take-profit
    atm_window: str = "15min"
    position_size: int = 1
    end_time: str = "15:15"  # HH:MM
    entry_buffer_pct: float = 0.1
    lookback_intervals: int = 4
    min_iv: float = 25
    min_oi_change: float = 0
    breakeven_trigger_pct: float = 2
    sar_enabled: bool = True

class MyNSEStrategy(Strategy):
    def __init__(self, config: MyNSEStrategyConfig):
        super().__init__(config=config)
        self.position = None
        self.entry_price = None
        self.sl_price = None
        self.tp_price = None
        self.last_price = None
        self.position_open_time = None
        self.rolling_last = deque(maxlen=self.config.lookback_intervals)
        self.rolling_ticks = deque(maxlen=self.config.lookback_intervals)
        self.direction = None  # 'long' or None
        self.breakeven_triggered = False

    def on_start(self):
        self.subscribe_quote_ticks(self.config.instrument_id)

    def on_quote_tick(self, tick: QuoteTick):
        price = float(tick.last)
        # Maintain rolling last prices
        self.rolling_last.append(price)

        if len(self.rolling_last) < self.config.lookback_intervals:
            return  # wait until enough data

        prev_top = max(self.rolling_last)
        prev_bottom = min(self.rolling_last)

        tick_time = pd.Timestamp(tick.ts_event, unit='ns').time()
        eod_time = time.fromisoformat(self.config.end_time)
        eod_squareoff_time = time(hour=15, minute=20)
        # For this example, assume custom fields are in tick.extra dict
        totalBuyQuantity = float(getattr(tick, 'totalBuyQuantity', tick.extra.get('totalBuyQuantity', 0)))
        totalSellQuantity = float(getattr(tick, 'totalSellQuantity', tick.extra.get('totalSellQuantity', 0)))
        pchangeinOpenInterest = float(getattr(tick, 'pchangeinOpenInterest', tick.extra.get('pchangeinOpenInterest', 0)))
        impliedVolatility = float(getattr(tick, 'impliedVolatility', tick.extra.get('impliedVolatility', 0)))

        # EOD logic: square off before or at 15:20
        if tick_time >= eod_squareoff_time:
            if self.position:
                self.close_position(self.position)
                self.position = None
            return

        # Update rolling window
        self.rolling_ticks.append(tick)

        # ENTRY LOGIC
        entry_trigger = price > prev_top * (1 + self.config.entry_buffer_pct / 100)
        iv = float(tick.extra.get("impliedVolatility", 0))
        oi_change = float(tick.extra.get("pchangeinOpenInterest", 0))

        buy_pressure = totalBuyQuantity > totalSellQuantity
        iv_ok = iv >= self.config.min_iv
        oi_ok = oi_change >= self.config.min_oi_change

        if not self.position and entry_trigger and buy_pressure and iv_ok and oi_ok:
            self.send_order(
                instrument_id=self.config.instrument_id,
                side=OrderSide.BUY,
                quantity=Quantity.from_int(self.config.position_size),
                tag="entry-long"
            )
            self.entry_price = price
            self.sl_price = prev_bottom
            self.tp_price = price * (1 + self.config.tp_pct / 100)
            self.position_open_time = tick.ts_event
            self.breakeven_triggered = False
            self.direction = "long"

            if self.direction == "long" and not self.breakeven_triggered:
                if price >= self.entry_price * (1 + self.config.breakeven_trigger_pct / 100):
                    self.sl_price = self.entry_price
                    self.breakeven_triggered = True
        # POSITION MANAGEMENT
        elif self.position is not None:
            # Breakeven rule
            if not self.breakeven_triggered and price >= self.entry_price * (1 + self.config.breakeven_trigger_pct / 100):
                self.sl_price = self.entry_price
                self.breakeven_triggered = True
            # Trailing SL: update SL if new higher low forms
            if prev_bottom > self.sl_price:
                self.sl_price = prev_bottom
            # TP/SL logic
            if self.direction == "long":
                if price <= self.sl_price:
                    self.send_order(
                        instrument_id=self.config.instrument_id,
                        side=OrderSide.SELL,
                        quantity=Quantity.from_int(self.config.position_size),
                        tag="exit-sl"
                    )
                    self._reset_position()

                elif price >= self.tp_price:
                    self.send_order(
                        instrument_id=self.config.instrument_id,
                        side=OrderSide.SELL,
                        quantity=Quantity.from_int(self.config.position_size),
                        tag="exit-tp"
                    )
                    self._reset_position()
            else:
                # SAR logic
                if self.config.sar_enabled:
                    # Check for opposite breakout (for now, only long-to-long SAR)
                    sar_entry_cond = (
                        price > prev_top * (1 + self.config.entry_buffer_pct)
                        and totalBuyQuantity > totalSellQuantity
                        and pchangeinOpenInterest > self.config.min_oi_change
                        and impliedVolatility > self.config.min_iv
                    )
                    if sar_entry_cond:
                        # Reverse and double position size
                        self.entry_price = price
                        self.sl_price = prev_bottom
                        self.tp_price = price * (1 + self.config.tp_pct)
                        self.breakeven_triggered = False
                        order = self.order_factory.market(
                            instrument_id=self.config.instrument_id,
                            order_side=OrderSide.BUY,
                            quantity=Quantity.from_int(self.config.position_size * 2),
                        )
                        self.submit_order(order)
                        self.position_open_time = tick_time
                        self.direction = 'long'
                        return
                # Otherwise, just close
                self.close_position(self.position)
                self.position = None
                self.direction = None
        self.last_price = price

        if tick_time >= eod_squareoff_time and self.direction == "long":
            self.send_order(
                instrument_id=self.config.instrument_id,
                side=OrderSide.SELL,
                quantity=Quantity.from_int(self.config.position_size),
                tag="eod-squareoff"
            )
            self._reset_position()

    def on_event(self, event: Event):
        if isinstance(event, PositionOpened):
            self.position = self.cache.position(event.position_id)

    def _reset_position(self):
        self.entry_price = None
        self.sl_price = None
        self.tp_price = None
        self.position_open_time = None
        self.breakeven_triggered = False
        self.direction = None
        self.rolling_last.clear()
        self.rolling_ticks.clear() 